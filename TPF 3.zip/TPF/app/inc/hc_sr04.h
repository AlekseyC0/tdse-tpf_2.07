#ifndef __HC_SR04_H
#define __HC_SR04_H

#include <stdint.h>
#include <stdbool.h>

void HCSR04_Init(void);
void HCSR04_Trigger(void);  // Inicia una medición
bool HCSR04_Ready(void);    // true si hay nueva medición
uint16_t HCSR04_GetLast(void);  // Devuelve la última distancia medida

#endif
