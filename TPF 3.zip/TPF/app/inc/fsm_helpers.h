
#include <stdint.h>
#include <stdbool.h>
#include "fsm_3.h"

extern uint8_t resultado_autotest;

// Códigos de error por tipo de test
#define ERROR_LCD          1
#define ERROR_ULTRASONICO  2
#define ERROR_EEPROM       3
#define ERROR_ADC          4
#define ERROR_LED          5
void button_update(void);        // Llamar cada ciclo del super loop
bool boton1_presionado(void);
bool boton2_presionado(void);
bool boton_azul_presionado(void);
bool joystick_arriba(void);
bool joystick_abajo(void);
bool joystick_izquierda(void);
bool joystick_derecha(void);
void mostrar_estado_leds(estados est);
void actualizar_temperatura_actual(void);
bool cafe_listo(void);
bool boton1_falling_edge(void);
bool sistema_autotest_ok(void);
bool boton3_presionado(void);
