

#ifndef __I2C_LCD_H__
#define __I2C_LCD_H__

#include "stm32f1xx_hal.h"
#include <stdbool.h>

#define SLAVE_ADDRESS_LCD 0x4E

// Inicializa el LCD
void lcd_init(void);

// Borra el contenido del LCD
void lcd_clear(void);

// Posiciona el cursor (0 o 1 para la fila, 0 a 15 para columna)
void lcd_put_cur(int row, int col);

// Envía un string entero (bloqueante)
void lcd_send_string(const char *str);

// Envía un número entero como string (bloqueante)
void lcd_enviar_int(int numero, int row, int col);

// Escribe un string completo en una posición
void lcd_enviar(char *string, int row, int col);

// Barrido de texto animado
void lcd_barrido(char *message);

// === NO BLOQUEANTE ===

// Solicita imprimir una línea, si cambió (inicia FSM interna)
void lcd_print_if_changed(int row, const char* str);

// Se llama periódicamente para imprimir un carácter por ciclo
void lcd_fsm_update(void);

#endif  // __I2C_LCD_H__
