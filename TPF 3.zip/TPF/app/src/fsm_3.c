#include "fsm_3.h"
#include "i2c_lcd.h"
#include "stock.h"
#include "gpio_control.h"
#include "eeprom.h"
#include <stdio.h>
#include <stdlib.h>
#include "hc_sr04.h"
#include "fsm_helpers.h"


extern uint8_t temp_deseada;
extern uint8_t temp_actual;
extern uint8_t nueva_temp;
extern int32_t ultima_interaccion_ms;
extern uint32_t inicio_brewing_ms;
extern const uint32_t DURACION_BREWING_MS;
extern uint32_t adc_value[3];
const uint32_t IDLE_TIMEOUT_MS = 30000;
extern I2C_HandleTypeDef hi2c2;

// === Variables globales ===
estados estado_actual = estado_off;
tipo_de_cafe cafe_seleccionado = CAFE_LATTE;

// === Delay interno no bloqueante ===
static uint32_t fsm_timer_ms = 0;
static uint8_t fsm_subestado = 0;

uint8_t receta_personal[4] = {0};  // Para guardar en EEPROM // café, leche, agua, chocolate


// === FSM principal ===
void fsm_update(void) {
    actualizar_temperatura_actual();


    if (boton1_presionado())
        ultima_interaccion_ms = HAL_GetTick();

    if(boton2_presionado()){
    	HAL_Delay(1000);
    	lcd_print_if_changed(0, "Reiniciando...");
    	HAL_Delay(2000);
    	NVIC_SystemReset();
    }


    switch (estado_actual) {

    case estado_diagnostico:
        static bool test_ejecutado = false;
        if (!test_ejecutado) {
            lcd_print_if_changed(0, "Testeando...");
            if (sistema_autotest_ok()) {
                lcd_print_if_changed(0, "Todo OK!");
                NVIC_SystemReset();
            } else {
                lcd_print_if_changed(0, "Falla detectada");
                estado_actual = estado_error;
            }
            test_ejecutado = true;
            fsm_timer_ms = HAL_GetTick();
        }
        break;

    case estado_off:
        switch (fsm_subestado) {
            case 0:  // Mostrar pantalla inicial (si querés)
                mostrar_estado_leds(estado_actual);
               lcd_print_if_changed(0, "Presione Start  ");

               lcd_print_if_changed(1, "Mod Fab: BotAzul");
                fsm_subestado = 1;
                break;

            case 1:  // Esperar interacción del usuario
                if (boton1_presionado()) {
                 lcd_print_if_changed(0, "Cargando...");
                   eeprom_start_read();  // <-- INICIO NO BLOQUEANTE
                    fsm_subestado = 2;
                } else if (boton3_presionado()) {
                  lcd_print_if_changed(0, "Modo FAB...");
                    fsm_timer_ms = HAL_GetTick();
                    fsm_subestado = 3;
                }
                break;

            case 2:  // Esperar a que termine la lectura EEPROM

                if (eeprom_terminado) {
                lcd_print_if_changed(0, "Konnichiwa!!");
                   lcd_print_if_changed(1, "");
                    fsm_timer_ms = HAL_GetTick();
                    fsm_subestado = 4;
                }
                break;

            case 3:  // Delay y luego carga EEPROM para modo FAB
                if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                  lcd_print_if_changed(0, "Cargando EEPROM");
                 lcd_print_if_changed(1, "");
                    eeprom_start_read();
                    fsm_subestado = 5;
                }
                break;

            case 4:  // Mostrar mensaje y luego continuar
                if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                   lcd_print_if_changed(0, "Espere...");
                   lcd_print_if_changed(1, "");
                    fsm_timer_ms = HAL_GetTick();
                    fsm_subestado = 6;
                }
                break;

            case 5:  // Esperar a que termine EEPROM en modo FAB
                eeprom_update();
                if (eeprom_terminado) {
                    estado_actual = estado_fabricante;
                    fsm_subestado = 0;
                }
                break;

            case 6:  // Transición a menú principal
                if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                    estado_actual = estado_menu_principal;
                    fsm_subestado = 0;
                }
                break;
        }
        break;

            case estado_fabricante: {
                static uint8_t menu_idx = 0;
                const char* menus[] = { "Stock actual", "Temp deseada", "Prueba de HW" };

                switch (fsm_subestado) {
                    case 0:
                    	mostrar_estado_leds(estado_actual);
                        lcd_print_if_changed(0, "FAB: Seleccione ");
                        lcd_print_if_changed(1, menus[menu_idx]);

                        // Navegación hacia abajo
                        if (joystick_abajo()) {
                            menu_idx = (menu_idx + 1) % 3;
                            fsm_timer_ms = HAL_GetTick();
                            fsm_subestado = 1;
                        }

                        // Navegación hacia arriba (manejo circular)
                        if (joystick_arriba()) {
                            menu_idx = (menu_idx + 2) % 3;  // Equivalente a -1 con módulo
                            fsm_timer_ms = HAL_GetTick();
                            fsm_subestado = 1;
                        }

                        // Selección
                        if (boton1_presionado()) {
                            switch (menu_idx) {
                                case 0: estado_actual = estado_submenu_stock; break;
                                case 1: estado_actual = estado_submenu_temp_deseada; break;
                                case 2: estado_actual = estado_diagnostico; break;
                            }
                            fsm_subestado = 0;
                        }

                        // Salir
                        if (joystick_izquierda()) {
                            lcd_print_if_changed(0, "Saliendo...");
                            lcd_print_if_changed(1, " ");
                            fsm_timer_ms = HAL_GetTick();
                            fsm_subestado = 2;
                        }
                        break;

                    case 1:
                        if (HAL_GetTick() - fsm_timer_ms >= 150) {
                            fsm_subestado = 0;
                        }
                        break;

                    case 2:
                        if (HAL_GetTick() - fsm_timer_ms >= 500) {
                            estado_actual = estado_off;
                            fsm_subestado = 0;
                        }
                        break;
                }
                break;
            }

        case estado_submenu_stock: {
            static uint8_t idx = 0;
            static int nuevo = 0;
            static bool edit = false;
            const char* nombres[] = { "Cafe", "Leche", "Agua", "Choc" };
            int* stocks[] = { &stock_cafe, &stock_leche, &stock_agua, &stock_chocolate };
            static bool boton1_espera_liberacion = false;

            switch (fsm_subestado) {
                case 0:  // Mostrar stock actual


                    if (!edit) {
                        char linea[16];
                        snprintf(linea, sizeof(linea), "%s: Stock=%d", nombres[idx], *stocks[idx]);
                        lcd_print_if_changed(1, linea);
                        lcd_print_if_changed(0, "Indique stock...");
                    } else {
                        char linea[17];
                        snprintf(linea, sizeof(linea), "Nuevo %s: %2d", nombres[idx], nuevo);
                        lcd_print_if_changed(0, linea);
                    }
                    fsm_subestado = 1;
                    break;

                case 1:  // Esperar interacción
                    if (!edit) {
                    	if (joystick_arriba()) {
                    	    idx = (idx + 1) % 4;
                    	    fsm_subestado = 0;
                    	}
                    	if (joystick_abajo()) {
                    	    idx = (idx == 0) ? 3 : idx - 1;
                    	    fsm_subestado = 0;
                    	}
                        if (boton1_presionado() && !boton1_espera_liberacion) {
                            edit = true;
                            nuevo = *stocks[idx];
                            fsm_subestado = 0;
                            boton1_espera_liberacion = true;
                        }

                    } else {
                    	if (joystick_arriba()) {
                    	    nuevo = (nuevo + 1) % 21;
                    	    fsm_subestado = 0;
                    	}
                    	if (joystick_abajo()) {
                    	    nuevo = (nuevo == 0) ? 20 : nuevo - 1;
                    	    fsm_subestado = 0;
                    	}
                        if (boton1_presionado() && !boton1_espera_liberacion) {
                            *stocks[idx] = nuevo;
                            edit = false;
                            lcd_print_if_changed(0, "Guardando...");
                            fsm_timer_ms = HAL_GetTick();
                            fsm_subestado = 2;
                            boton1_espera_liberacion = true;
                        }
                    }
                    if (!boton1_presionado()) {
                        boton1_espera_liberacion = false;
                    }
                    break;

                case 2:  // Iniciar guardado no bloqueante
                    lcd_print_if_changed(0, "Guardando...");
                    eeprom_start_save();
                    fsm_subestado = 12;
                    break;

                case 12:  // Esperar que EEPROM termine de guardar
                    if (eeprom_terminado) {
                        eeprom_terminado = 0;  // limpiar flag
                        lcd_print_if_changed(0, "Stock Guardado!");
                        fsm_timer_ms = HAL_GetTick();
                        fsm_subestado = 3;
                    }
                    break;

                case 3:  // Esperar y volver al paso 0
                    if (HAL_GetTick() - fsm_timer_ms >= 600) {
                        fsm_subestado = 0;
                    }
                    break;

                case 10:  // Salida: mostrar mensaje
                    lcd_print_if_changed(0, "Saliendo...");
                    lcd_print_if_changed(1, "");
                    fsm_timer_ms = HAL_GetTick();
                    fsm_subestado = 11;
                    break;

                case 11:  // Esperar salida
                    if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                        estado_actual = estado_fabricante;
                        fsm_subestado = 0;
                    }
                    break;
            }

            // Chequeo de salida
            if (joystick_izquierda() && fsm_subestado < 10) {
                fsm_subestado = 10;
            }

            break;
        }



        case estado_submenu_temp_deseada:
            switch (fsm_subestado) {
                case 0:
                    lcd_print_if_changed(0, "Edit Temp");
                    nueva_temp = (adc_value[0] * 60) / 4095 + 30;
                    {
                        char linea[16];
                        snprintf(linea, sizeof(linea), "T: %d/%d", nueva_temp, temp_deseada);
                        lcd_print_if_changed(1, linea);
                    }

                    if (boton1_presionado()) {
                        temp_deseada = nueva_temp;
                        lcd_print_if_changed(0, "Guardando...");
                        eeprom_start_save();
                        fsm_subestado = 10;
                    }

                    if (joystick_izquierda()) {
                        lcd_print_if_changed(0, "Saliendo...");
                        lcd_print_if_changed(1, "");
                        fsm_timer_ms = HAL_GetTick();
                        fsm_subestado = 2;
                    }
                    break;

                case 10:  // Esperar a que finalice guardado EEPROM
                    if (eeprom_terminado) {
                        eeprom_terminado = 0;
                        lcd_print_if_changed(0, "Temp Guardada!");
                        fsm_timer_ms = HAL_GetTick();
                        fsm_subestado = 1;
                    }
                    break;

                case 1:
                    if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                        fsm_subestado = 0;
                    }
                    break;

                case 2:
                    if (HAL_GetTick() - fsm_timer_ms >= 500) {
                        estado_actual = estado_fabricante;
                        fsm_subestado = 0;
                    }
                    break;
            }
            break;





        case estado_menu_principal:
            switch (fsm_subestado) {
                case 0:  // Mostrar "Calentando"
                	mostrar_estado_leds(estado_actual);
                    if (temp_actual < temp_deseada) {
                       lcd_print_if_changed(0, "Calentando...   ");
                        char linea[16];
                        snprintf(linea, sizeof(linea), "T:%d/%d", temp_actual, temp_deseada);
                       lcd_print_if_changed(1, linea);
                    } else {
                     lcd_print_if_changed(0, "Selecciona cafe ");
                   lcd_print_if_changed(1, "mueva el cursor");
                        ultima_interaccion_ms = HAL_GetTick();
                        fsm_subestado = 1;
                    }
                    break;

                case 1:  // Transición a selección
                    estado_actual = estado_seleccion_cafe;
                    fsm_subestado = 0;
                    break;
            }
            break;



            case estado_seleccion_cafe:
            				mostrar_estado_leds(estado_actual);

                               switch (fsm_subestado) {
                                   case 0: {
                                       const char* nombres[] = {
                                           "Latte", "Mocha", "Doble", "Americano",
                                           "Pers. nuevo", "Pers. reciente"
                                       };

                                       char buf[17];
                                      lcd_print_if_changed(0, nombres[cafe_seleccionado]);

                                       if (cafe_seleccionado < CAFE_PERSONALIZADO) {
                                           snprintf(buf, sizeof(buf), "Temp=%dC  ", temp_actual);
                                       } else if (cafe_seleccionado == CAFE_PERSONALIZADO) {
                                           snprintf(buf, sizeof(buf), "Configura nuevo");
                                       } else {
                                           snprintf(buf, sizeof(buf), "Usar ultimo");
                                       }

                                      lcd_print_if_changed(1, buf);

                                      // last_cafe = cafe_seleccionado;
                                       fsm_subestado = 1;
                                       break;
                                   }

                                   case 1:
                                       if (joystick_arriba()) {
                                           cafe_seleccionado = (cafe_seleccionado + 1) % TOTAL_CAFES;
                                           fsm_subestado = 0;
                                       }

                                       if (joystick_abajo()) {
                                           cafe_seleccionado = (cafe_seleccionado == 0) ? TOTAL_CAFES - 1 : cafe_seleccionado - 1;
                                           fsm_subestado = 0;
                                       }

                                       if (boton1_falling_edge()) {
                                           if (cafe_seleccionado == CAFE_PERSONALIZADO) {
                                               estado_actual = estado_cafe_personalizado;
                                               fsm_subestado = 0;
                                           }
                                           else if (cafe_seleccionado == CAFE_ULTIMO) {
                                               if (check_stock_receta(receta_personal)) {
                                                   descontar_stock_receta(receta_personal);
                                                   lcd_print_if_changed(0, "Preparando...");
                                                   inicio_brewing_ms = HAL_GetTick();
                                                   fsm_subestado = 2;
                                               } else {
                                                   lcd_print_if_changed(0, "Sin stock!");
                                                   fsm_timer_ms = HAL_GetTick();
                                                   fsm_subestado = 3;
                                               }
                                           }
                                           else {
                                               if (check_stock(cafe_seleccionado)) {
                                                   descontar_stock(cafe_seleccionado);
                                                   lcd_print_if_changed(0, "Preparando...");
                                                   inicio_brewing_ms = HAL_GetTick();
                                                   fsm_subestado = 2;
                                               } else {
                                                   lcd_print_if_changed(0, "Sin stock!");
                                                   fsm_timer_ms = HAL_GetTick();
                                                   fsm_subestado = 3;
                                               }
                                           }
                                       }

                                       if (joystick_izquierda()) {
                                           lcd_print_if_changed(0, "Saliendo...");
                                           lcd_print_if_changed(1, " ");
                                           fsm_timer_ms = HAL_GetTick();
                                           fsm_subestado = 4;
                                       }

                                       if (temp_actual <= temp_deseada) {
                                           estado_actual = estado_menu_principal;
                                           fsm_subestado = 0;
                                       }

                                       if (HAL_GetTick() - ultima_interaccion_ms > IDLE_TIMEOUT_MS) {
                                           estado_actual = estado_save_energy;
                                           fsm_subestado = 0;
                                       }

                                       break;

                                   case 2:
                                       eeprom_start_save();  // iniciar guardado no bloqueante
                                       fsm_subestado = 5;
                                       break;

                                   case 5:  // Esperar a que EEPROM termine
                                       if (eeprom_terminado) {
                                           eeprom_terminado = 0;
                                           estado_actual = estado_brewing;
                                           fsm_subestado = 0;
                                       }
                                       break;

                                   case 3:
                                       if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                                           fsm_subestado = 0;
                                       }
                                       break;

                                   case 4:
                                       if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                                           estado_actual = estado_off;
                                           fsm_subestado = 0;
                                       }
                                       break;
                               }
                               break;

                               case estado_cafe_personalizado: {
                                   static uint8_t ingrediente_idx = 0;
                                   static uint8_t receta_tmp[4] = {0};
                                   static const char* nombres[] = { "Cafe", "Leche", "Agua", "Choc" };

                                   switch (fsm_subestado) {
                                       case 0:  // Mostrar ingrediente actual y cantidad
                                           {
                                               char buf[16];
                                               snprintf(buf, sizeof(buf), "%s: %2d", nombres[ingrediente_idx], receta_tmp[ingrediente_idx]);
                                               lcd_print_if_changed(0, buf);

                                               uint8_t total_shots = receta_tmp[0] + receta_tmp[1] + receta_tmp[2] + receta_tmp[3];
                                               snprintf(buf, sizeof(buf), "Shots: %d", total_shots);
                                               lcd_print_if_changed(1, buf);

                                               fsm_subestado = 1;
                                           }
                                           break;

                                       case 1:  // Espera interacción
                                           if (joystick_arriba()) {
                                               if (receta_tmp[ingrediente_idx] < 20 &&
                                                   (receta_tmp[0] + receta_tmp[1] + receta_tmp[2] + receta_tmp[3]) < 4 &&
                                                   receta_tmp[ingrediente_idx] < get_stock(ingrediente_idx)) {
                                                   receta_tmp[ingrediente_idx]++;
                                               }
                                               fsm_subestado = 0;
                                           }

                                           if (joystick_abajo()) {
                                               if (receta_tmp[ingrediente_idx] > 0) {
                                                   receta_tmp[ingrediente_idx]--;
                                               }
                                               fsm_subestado = 0;
                                           }

                                           if (joystick_derecha()) {
                                               ingrediente_idx = (ingrediente_idx + 1) % 4;
                                               fsm_subestado = 0;
                                           }

                                           if (boton1_falling_edge()) {
                                               uint8_t total = receta_tmp[0] + receta_tmp[1] + receta_tmp[2] + receta_tmp[3];
                                               if (total == 4 &&
                                                   receta_tmp[0] <= stock_cafe &&
                                                   receta_tmp[1] <= stock_leche &&
                                                   receta_tmp[2] <= stock_agua &&
                                                   receta_tmp[3] <= stock_chocolate) {

                                                   // Aplicar receta y descontar
                                                   receta_personal[0] = receta_tmp[0];
                                                   receta_personal[1] = receta_tmp[1];
                                                   receta_personal[2] = receta_tmp[2];
                                                   receta_personal[3] = receta_tmp[3];

                                                   stock_cafe      -= receta_tmp[0];
                                                   stock_leche     -= receta_tmp[1];
                                                   stock_agua      -= receta_tmp[2];
                                                   stock_chocolate -= receta_tmp[3];

                                                   cafe_seleccionado = CAFE_PERSONALIZADO;


                                                   eeprom_start_save();  // Inicia escritura no bloqueante

                                                   lcd_print_if_changed(0, "Guardando...");
                                                   lcd_print_if_changed(1, "");
                                                   fsm_subestado = 4;
                                               } else {
                                                   lcd_print_if_changed(0, "Error!");
                                                   lcd_print_if_changed(1, "Stock/Max=4!");
                                                   fsm_timer_ms = HAL_GetTick();
                                                   fsm_subestado = 3;
                                               }
                                           }
                                           break;
                                       case 4:  // Espera EEPROM y prepara si termina
                                           if (eeprom_terminado) {
                                               eeprom_terminado = 0;
                                               lcd_print_if_changed(0, "Guardado!");
                                               lcd_print_if_changed(1, "Preparando...");
                                               inicio_brewing_ms = HAL_GetTick();
                                               fsm_subestado = 2;
                                           }
                                           break;

                                       case 2:  // Ir a brewing luego de un delay corto
                                           if (HAL_GetTick() - inicio_brewing_ms >= 800) {
                                               estado_actual = estado_brewing;
                                               fsm_subestado = 0;
                                           }
                                           break;

                                       case 3:  // Mostrar error por un momento
                                           if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                                               fsm_subestado = 0;
                                           }
                                           break;
                                   }
                                   break;
                               }

                               case estado_brewing: {
                                   static uint8_t ingrediente_actual = 0;
                                   static uint8_t shots_restantes[4] = {0};
                                   static uint32_t shot_start_time = 0;
                                   static bool primera_carga = true;
                                   static bool taza_detectada = false;

                                   switch (fsm_subestado) {
                                       case 0: // Estado inicial - detectar taza
                                    	   mostrar_estado_leds(estado_actual);
                                    	   lcd_print_if_changed(0, "Coloque la taza");
                                    	   lcd_print_if_changed(1, "                ");
                                           HCSR04_Trigger();
                                           fsm_timer_ms = HAL_GetTick();
                                           taza_detectada = false;
                                           fsm_subestado = 1;
                                           break;

                                       case 1: // Esperando detección de taza
                                           if (HCSR04_Ready()) {
                                               uint16_t distancia = HCSR04_GetLast();
                                               if (distancia > 0 && distancia <= 3) {
                                                   taza_detectada = true;
                                                   lcd_print_if_changed(0, "Preparando...");
                                                   fsm_subestado = 2;
                                               } else {
                                                   fsm_timer_ms = HAL_GetTick();
                                                   fsm_subestado = 3; // Reintentar detección
                                               }
                                           }
                                           break;

                                       case 2: // Inicializar receta
                                           if (taza_detectada) {
                                               // Cargar receta según selección
                                               if (cafe_seleccionado < CAFE_PERSONALIZADO) {
                                                   shots_restantes[0] = recetas[cafe_seleccionado].cafe;
                                                   shots_restantes[1] = recetas[cafe_seleccionado].leche;
                                                   shots_restantes[2] = recetas[cafe_seleccionado].agua;
                                                   shots_restantes[3] = recetas[cafe_seleccionado].chocolate;
                                               } else {
                                                   // Personalizado o último
                                                   memcpy(shots_restantes, receta_personal, sizeof(shots_restantes));
                                               }
                                               ingrediente_actual = 0;
                                               primera_carga = true;
                                               fsm_subestado = 10; // Comenzar secuencia de shots
                                           }
                                           break;

                                       case 3: // Reintentar detección
                                           if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                                               HCSR04_Trigger();
                                               fsm_subestado = 1;
                                           }
                                           break;

                                       case 10: // Preparar siguiente shot
                                           if (primera_carga) {
                                               // Buscar primer ingrediente con shots
                                               while (ingrediente_actual < 4 && shots_restantes[ingrediente_actual] == 0) {
                                                   ingrediente_actual++;
                                               }
                                               primera_carga = false;
                                           }

                                           if (ingrediente_actual >= 4) {
                                               // Todos los shots completados
                                        	   lcd_print_if_changed(0, "Cafe listo!");
                                        	   lcd_print_if_changed(1, "Retire la taza");
                                               fsm_subestado = 20; // Esperar retiro de taza
                                           } else {
                                               // Encender LED correspondiente (1-4)
                                               led_off(ingrediente_actual + 1);
                                               shot_start_time = HAL_GetTick();
                                               fsm_subestado = 11;
                                           }
                                           break;

                                       case 11: // Mantener LED encendido
                                           if (HAL_GetTick() - shot_start_time >= 1000) {
                                               led_on(ingrediente_actual + 1);
                                               shots_restantes[ingrediente_actual]--;
                                               fsm_subestado = 12;
                                           }
                                           break;

                                       case 12: // Pequeña pausa entre shots
                                           if (HAL_GetTick() - shot_start_time >= 1200) {
                                               if (shots_restantes[ingrediente_actual] > 0) {
                                                   // Mismo ingrediente, siguiente shot
                                                   fsm_subestado = 10;
                                               } else {
                                                   // Pasar al siguiente ingrediente
                                                   ingrediente_actual++;
                                                   primera_carga = true;
                                                   fsm_subestado = 10;
                                               }
                                           }
                                           break;

                                       case 20: // Esperar que retiren la taza
                                           HCSR04_Trigger();
                                           fsm_subestado = 21;
                                           break;

                                       case 21: // Verificar si retiraron la taza
                                           if (HCSR04_Ready()) {
                                               uint16_t distancia = HCSR04_GetLast();
                                               if (distancia > 4 || distancia == 0xFFFF) {
                                                   estado_actual = estado_menu_principal;
                                                   fsm_subestado = 0;
                                               } else {
                                                   fsm_timer_ms = HAL_GetTick();
                                                   fsm_subestado = 22;
                                               }
                                           }
                                           break;

                                       case 22: // Reintentar verificación
                                           if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                                               fsm_subestado = 20;
                                           }
                                           break;
                                   }
                                   break;
                               }

        case estado_save_energy:
            switch (fsm_subestado) {
                case 0:
                	mostrar_estado_leds(estado_actual);
                	lcd_print_if_changed(1, "");
                    lcd_print_if_changed(0, "Modo ahorro...  ");
                    fsm_timer_ms = HAL_GetTick();
                    fsm_subestado = 1;
                    break;

                case 1:
                	uint32_t ahora = HAL_GetTick();
                    if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                        fsm_subestado = 2;
                    }
                    break;

                case 2:
                    if (joystick_derecha() || joystick_arriba() || boton1_falling_edge() || joystick_izquierda() || joystick_abajo()||boton3_presionado()) {
                        lcd_print_if_changed(0, "Reactivando...  ");
                        lcd_print_if_changed(1, "");
                        fsm_timer_ms = HAL_GetTick();
                        fsm_subestado = 3;
                    }else{
                    	__WFI();
                    }
                    break;

                case 3:
                	ahora = HAL_GetTick();
                    if (ahora - fsm_timer_ms >= 1000) {
                        led_off(4);
                        estado_actual = estado_menu_principal;
                        ultima_interaccion_ms = HAL_GetTick();
                        fsm_subestado = 0;
                    }
                    break;
            }
            break;


            case estado_error:
                switch (fsm_subestado) {
                    case 0:
                        lcd_print_if_changed(0, "ERROR DE HARDWARE");
                        lcd_print_if_changed(1, "Presione Azul");
                        fsm_subestado = 1;
                        break;

                    case 1:
                        if (boton3_presionado()) {
                            lcd_print_if_changed(0, "Reiniciando...");
                            lcd_print_if_changed(1, " ");
                            fsm_timer_ms = HAL_GetTick();
                            fsm_subestado = 2;
                        }
                        break;

                    case 2:
                        if (HAL_GetTick() - fsm_timer_ms >= 1000) {
                            estado_actual = estado_diagnostico;
                            fsm_subestado = 0;
                        }
                        break;
                }
                break;
    }
}


