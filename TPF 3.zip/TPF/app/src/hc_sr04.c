#include "hc_sr04.h"
#include "stm32f1xx_hal.h"

#define TRIG_GPIO GPIOC
#define TRIG_PIN  GPIO_PIN_7

extern TIM_HandleTypeDef htim1; // ECHO en TIM1_CH1 (por ejemplo, PA8)

static volatile uint32_t t_ini = 0;
static volatile uint32_t t_end = 0;
static volatile uint16_t dist = 0;
static volatile bool flag_ready = false;
static volatile uint8_t fase = 0;

void delay_us(uint16_t us) {
    uint32_t start = __HAL_TIM_GET_COUNTER(&htim1);  // Timer a 1 MHz (1 tick = 1 µs)
    while ((__HAL_TIM_GET_COUNTER(&htim1) - start) < us);
}
void HCSR04_Init(void) {
    // Configurar TRIG como salida
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOC_CLK_ENABLE();
    GPIO_InitStruct.Pin = TRIG_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(TRIG_GPIO, &GPIO_InitStruct);
    HAL_GPIO_WritePin(TRIG_GPIO, TRIG_PIN, GPIO_PIN_RESET);

    // Iniciar captura
    HAL_TIM_IC_Start_IT(&htim1, TIM_CHANNEL_1);
    __HAL_TIM_SET_CAPTUREPOLARITY(&htim1, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);
}

void HCSR04_Trigger(void) {
    if (fase != 0) return;  // aún midiendo
    flag_ready = false;
    fase = 1;

    HAL_GPIO_WritePin(TRIG_GPIO, TRIG_PIN, GPIO_PIN_SET);
    delay_us(10);// 10 us mínimo
    HAL_GPIO_WritePin(TRIG_GPIO, TRIG_PIN, GPIO_PIN_RESET);
}

bool HCSR04_Ready(void) {
    return flag_ready;
}

uint16_t HCSR04_GetLast(void) {
    flag_ready = false;
    return dist;
}

// Interrupción de captura
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim) {
    if (htim->Channel != HAL_TIM_ACTIVE_CHANNEL_1) return;

    if (fase == 1) {
        t_ini = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
        __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_FALLING);
        fase = 2;
    } else if (fase == 2) {
        t_end = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
        __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);

        uint32_t delta = (t_end >= t_ini) ? (t_end - t_ini) : (0xFFFF - t_ini + t_end);
        dist = (uint16_t)((delta * 0.0343f) / 2);  // 1 tick ≈ 1us si el timer está a 1MHz
        flag_ready = true;
        fase = 0;
    }
}
