#include "fsm_helpers.h"
#include "stm32f1xx_hal.h"
#include "gpio_control.h"
#include <stdlib.h>
#include <stdio.h>
#include "fsm_3.h"
#include "i2c_lcd.h"
#include "hc_sr04.h"
#include "eeprom.h"


#define DEBOUNCE_TIME_MS 20  // Tiempo mínimo para considerar una señal estable
#define JOY_UMBRAL 1000
#define JOY_CENTRO 2048
#define JOY_UMBRAL 1000
#define JOY_CENTRO 2048

uint8_t temp_deseada = 60;
uint8_t temp_actual = 25;
uint8_t nueva_temp;
int32_t ultima_interaccion_ms = 0;

uint32_t inicio_brewing_ms = 0;
const uint32_t DURACION_BREWING_MS = 5000;
extern uint32_t adc_value[3];
extern I2C_HandleTypeDef hi2c2;


bool boton_azul_presionado(void) {
    return HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET;
}

bool cafe_listo(void) {
    return (HAL_GetTick() - inicio_brewing_ms) >= DURACION_BREWING_MS;
}

bool joystick_arriba(void) {
    static bool prev_estado = false;
    bool estado_actual = (adc_value[1] > (JOY_CENTRO + JOY_UMBRAL));  // Y
    if (estado_actual && !prev_estado) {
        prev_estado = true;
        return true;
    } else if (!estado_actual) {
        prev_estado = false;
    }
    return false;
}

bool joystick_derecha(void) {
    static bool prev = false;
    bool now = (adc_value[2] > (JOY_CENTRO + JOY_UMBRAL));
    if (now && !prev) { prev = true; return true; }
    if (!now) prev = false;
    return false;
}

bool joystick_izquierda(void) {
    static bool prev = false;
    bool now = (adc_value[2] < (JOY_CENTRO - JOY_UMBRAL));  // eje X
    if (now && !prev) { prev = true; return true; }
    if (!now) prev = false;
    return false;
}

bool joystick_abajo(void) {
    static bool prev = false;
    bool now = (adc_value[1] < (JOY_CENTRO - JOY_UMBRAL));  // eje Y
    if (now && !prev) { prev = true; return true; }
    if (!now) prev = false;
    return false;
}


/*
void reset_fsm_subestado(void) {
    fsm_timer_ms = HAL_GetTick();
}

bool timeout_ms(uint32_t start, uint32_t ms) {
    return (HAL_GetTick() - start) >= ms;
}

void fsm_delay_ms(uint16_t ms) {
    uint32_t t = HAL_GetTick();
    while (HAL_GetTick() - t < ms);
}

void mostrar_nombre_cafe(uint8_t cafe) {
    const char* nombre[] = { "Latte", "Mocha", "Doble", "Americano" };
    if (cafe < 4) {
        lcd_print_if_changed(0, nombre[cafe]);
    } else {
        lcd_print_if_changed(0, "Cafe Invalido");
    }
}

void mostrar_temperatura(uint8_t actual, uint8_t deseada) {
    char buf[16];
    snprintf(buf, sizeof(buf), "T:%d/%d", actual, deseada);
    lcd_print_if_changed(1, buf);
}

void limpiar_pantalla(void) {
    lcd_print_if_changed(0, "                ");
    lcd_print_if_changed(1, "                ");
}
*/



typedef struct {
    GPIO_TypeDef* port;
    uint16_t pin;
    bool stable_state;
    bool last_read;
    uint32_t last_change_time;
} ButtonState;

static ButtonState boton1 = {BOTON1_GPIO_Port, BOTON1_Pin, false, false, 0}; // Ajusta el pin según tu hardware
static ButtonState boton2 = {BOTON2_GPIO_Port, BOTON2_Pin, false, false, 0};
static ButtonState boton3 = {BOTON3_GPIO_Port, BOTON3_Pin, false, false, 0};

void button_update(void) {
    // --- Botón 1 ---
    bool current1 = HAL_GPIO_ReadPin(boton1.port, boton1.pin);
    if (current1 != boton1.last_read) {
        boton1.last_change_time = HAL_GetTick();
        boton1.last_read = current1;
    }
    if ((HAL_GetTick() - boton1.last_change_time) > DEBOUNCE_TIME_MS) {
        boton1.stable_state = current1;
    }

    // --- Botón 2 ---
    bool current2 = HAL_GPIO_ReadPin(boton2.port, boton2.pin);
    if (current2 != boton2.last_read) {
        boton2.last_change_time = HAL_GetTick();
        boton2.last_read = current2;
    }
    if ((HAL_GetTick() - boton2.last_change_time) > DEBOUNCE_TIME_MS) {
        boton2.stable_state = current2;
    }
    // --- Botón 3 ---
        bool current3 = HAL_GPIO_ReadPin(boton3.port, boton3.pin);
        if (current3 != boton3.last_read) {
            boton3.last_change_time = HAL_GetTick();
            boton3.last_read = current3;
        }
        if ((HAL_GetTick() - boton3.last_change_time) > DEBOUNCE_TIME_MS) {
            boton3.stable_state = current3;
        }
}

bool boton1_presionado(void) {
    return boton1.stable_state;
}

bool boton2_presionado(void){
	return boton2.stable_state;
}

bool boton3_presionado(void){
	return boton3.stable_state;
}
void mostrar_estado_leds(estados est) {
    led_on(1); led_on(2); led_on(3); led_on(4);
    switch (est) {
        case estado_off:             led_off(1); break;
        case estado_menu_principal:  led_off(2); break;
        case estado_seleccion_cafe:  led_off(3); break;
        case estado_fabricante:      led_off(1); led_off(2); led_off(3); ; led_off(4); break;
        case estado_brewing:				led_on(1); led_on(2); led_on(3);; led_on(4); break;
        default: break;
    }
}

void actualizar_temperatura_actual(void) {
    static uint8_t temp_anterior = 0;
    uint8_t temp_leida = (adc_value[0] * 60) / 4095 + 30;
    if (abs((int)temp_leida - temp_anterior) >= 2) {
        temp_actual = temp_leida;
        temp_anterior = temp_leida;
    }
}

bool boton1_falling_edge(void) {
    static bool last_state = false;
    bool current_state = HAL_GPIO_ReadPin(BOTON1_GPIO_Port, BOTON1_Pin);  // reemplaza con tu puerto y pin

    bool falling_edge = (!current_state && last_state);
    last_state = current_state;
    return falling_edge;
}

bool sistema_autotest_ok(void) {
    // 1. Verificar LCD (mandar comando y ver que no se cuelga)
    lcd_send_cmd(0x01);  // Clear
    HAL_Delay(5);
    lcd_send_data('X');  // Si no se cuelga, pasa

    // 2. Verificar sensor ultrasónico
    HCSR04_Trigger();
    HAL_Delay(100);
    if (!HCSR04_Ready()) return false;
    uint16_t distancia = HCSR04_GetLast();
    if (distancia == 0xFFFF || distancia > 100) return false;

    // Escribir test
    	uint8_t test_val = 0xAB;
       uint8_t read_val = 0;
       HAL_StatusTypeDef status;

       status = HAL_I2C_Mem_Write(&hi2c2, EEPROM_I2C_ADDR, 0x01FF, I2C_MEMADD_SIZE_16BIT, &test_val, 1, 50);
      if (status != HAL_OK) return false;

       HAL_Delay(5); // esperar a que termine de escribir

       // Leer test
       status = HAL_I2C_Mem_Read(&hi2c2, EEPROM_I2C_ADDR, 0x01FF, I2C_MEMADD_SIZE_16BIT, &read_val, 1, 50);
       if (status != HAL_OK || read_val != test_val) return false;

    // 4. Verificar ADC (potenciómetro)
    if (adc_value[0] < 10 || adc_value[0] > 4090) return false;

    // 5. Verificar LEDs
    led_on(1);
    HAL_Delay(100);
    if (HAL_GPIO_ReadPin(LED1_GPIO_Port, LED1_Pin) != GPIO_PIN_RESET) return false;
    led_off(1);

    // 6. Verificar botones
    // Omitible si se testean durante la operación



    return true;
}


