/*#include "eeprom.h"
#include "stm32f1xx_hal.h"
#include "stock.h"
#include "fsm_3.h"

extern I2C_HandleTypeDef hi2c2;
#define EEPROM_I2C &hi2c2


#define ADDR_TEMP       0x0000
#define ADDR_CAFE       0x0001
#define ADDR_STOCK_BASE 0x0010  // Café, leche, agua, chocolate

// === Función auxiliar ===
static void eeprom_write_if_changed(uint16_t addr, uint8_t value) {
    uint8_t current = eeprom_read_byte(addr);
    if (current != value) {
        HAL_I2C_Mem_Write(EEPROM_I2C, EEPROM_I2C_ADDR, addr, I2C_MEMADD_SIZE_16BIT, &value, 1, HAL_MAX_DELAY);
        HAL_Delay(5);
    }
}

uint8_t eeprom_read_byte(uint16_t mem_address) {
    uint8_t data = 0;
    HAL_I2C_Mem_Read(EEPROM_I2C, EEPROM_I2C_ADDR, mem_address, I2C_MEMADD_SIZE_16BIT, &data, 1, HAL_MAX_DELAY);
    return data;
}

// === GUARDAR configuración solo si hubo cambios ===
bool eeprom_save_config(void) {
    bool guardo = false;

    // Temperatura
    uint8_t raw_temp = eeprom_read_byte(ADDR_TEMP);
    if (raw_temp != temp_deseada) {
        eeprom_write_if_changed(ADDR_TEMP, temp_deseada);
        guardo = true;
    }

    // Tipo de café
    uint8_t raw_cafe = eeprom_read_byte(ADDR_CAFE);
    if (raw_cafe != (uint8_t)cafe_seleccionado) {
        eeprom_write_if_changed(ADDR_CAFE, (uint8_t)cafe_seleccionado);
        guardo = true;
    }

    // Stocks
    const uint8_t stock_actual[4] = { stock_cafe, stock_leche, stock_agua, stock_chocolate };
    for (uint8_t i = 0; i < 4; i++) {
        uint8_t eeprom_stock = eeprom_read_byte(ADDR_STOCK_BASE + i);
        if (eeprom_stock != stock_actual[i]) {
            eeprom_write_if_changed(ADDR_STOCK_BASE + i, stock_actual[i]);
            guardo = true;
        }
    }

    return guardo;
}

// === CARGAR configuración desde EEPROM ===
void eeprom_load_config(void) {
    // Temperatura
	uint8_t raw_temp = eeprom_read_byte(ADDR_TEMP);
	if (raw_temp < 20 || raw_temp > 90) {
	    temp_deseada = 60;
	} else {
	    temp_deseada = raw_temp;
	}

    // Café seleccionado
    uint8_t raw_cafe = eeprom_read_byte(ADDR_CAFE);
    cafe_seleccionado = (raw_cafe <= CAFE_AMERICANO) ? (tipo_de_cafe)raw_cafe : CAFE_LATTE;

    // Stocks
    uint8_t raw_stock;
    raw_stock = eeprom_read_byte(ADDR_STOCK_BASE + 0);
    stock_cafe = (raw_stock <= 20) ? raw_stock : 10;

    raw_stock = eeprom_read_byte(ADDR_STOCK_BASE + 1);
    stock_leche = (raw_stock <= 20) ? raw_stock : 10;

    raw_stock = eeprom_read_byte(ADDR_STOCK_BASE + 2);
    stock_agua = (raw_stock <= 20) ? raw_stock : 10;

    raw_stock = eeprom_read_byte(ADDR_STOCK_BASE + 3);
    stock_chocolate = (raw_stock <= 20) ? raw_stock : 10;
}
*/

#include "eeprom.h"
#include "stm32f1xx_hal.h"
#include "stock.h"
#include "fsm_3.h"
#include "i2c_lcd.h"     // si usás I2C
#include "gpio_control.h"
#include "stm32f1xx_it.h"
#include "stm32f1xx_hal_conf.h"
#include "main.h"


extern I2C_HandleTypeDef hi2c2;
#define EEPROM_I2C &hi2c2
#define EEPROM_CONFIG_ADDR 0x0000
#define EEPROM_TIMEOUT     5  // milisegundos

extern uint8_t receta_personal[4];


static uint8_t eeprom_buffer[sizeof(ConfigEEPROM)];
static uint8_t eeprom_index = 0;
volatile uint8_t eeprom_terminado = 0;
volatile uint8_t eeprom_leyendo = 0;
volatile uint8_t eeprom_guardando = 0;
// eeprom_utils.c o eeprom.c


void eeprom_write_byte(uint16_t addr, uint8_t data) {
    HAL_I2C_Mem_Write(&hi2c2, EEPROM_I2C_ADDR, addr, I2C_MEMADD_SIZE_16BIT, &data, 1, EEPROM_TIMEOUT);
    HAL_Delay(5);  // Tiempo para que la EEPROM termine la escritura
}

uint8_t eeprom_read_byte(uint16_t addr) {
    uint8_t data = 0;
    HAL_I2C_Mem_Read(&hi2c2, EEPROM_I2C_ADDR, addr, I2C_MEMADD_SIZE_16BIT, &data, 1, EEPROM_TIMEOUT);
    return data;
}
// === GUARDAR configuración (solo si cambia) ===

void eeprom_start_save(void) {
    if (eeprom_guardando || eeprom_terminado) return;  // evitar solapamiento

    ConfigEEPROM nueva = {
        .temp_deseada = temp_deseada,
        .cafe_seleccionado = cafe_seleccionado,
        .stock = { stock_cafe, stock_leche, stock_agua, stock_chocolate },
        .receta_personal = {
            receta_personal[0], receta_personal[1],
            receta_personal[2], receta_personal[3]
        }
    };

    memcpy(eeprom_buffer, &nueva, sizeof(ConfigEEPROM));
    eeprom_index = 0;
    eeprom_guardando = 1;
    eeprom_terminado = 0;
}



// === CARGAR configuración desde EEPROM ===
void eeprom_load_config(void) {
    ConfigEEPROM leida;

    if (HAL_I2C_Mem_Read(EEPROM_I2C, EEPROM_I2C_ADDR, EEPROM_CONFIG_ADDR,
                         I2C_MEMADD_SIZE_16BIT, (uint8_t*)&leida, sizeof(leida), EEPROM_TIMEOUT) != HAL_OK) {
        // Fallback si hay error
        temp_deseada = 60;
        cafe_seleccionado = CAFE_LATTE;
        stock_cafe = stock_leche = stock_agua = stock_chocolate = 10;
        return;
    }

    // Validaciones básicas
    temp_deseada = (leida.temp_deseada >= 20 && leida.temp_deseada <= 90) ? leida.temp_deseada : 60;

    cafe_seleccionado = (leida.cafe_seleccionado <= CAFE_AMERICANO)
        ? leida.cafe_seleccionado : CAFE_LATTE;

    stock_cafe       = (leida.stock[0] <= 20) ? leida.stock[0] : 10;
    stock_leche      = (leida.stock[1] <= 20) ? leida.stock[1] : 10;
    stock_agua       = (leida.stock[2] <= 20) ? leida.stock[2] : 10;
    stock_chocolate  = (leida.stock[3] <= 20) ? leida.stock[3] : 10;
    receta_personal[0] = leida.receta_personal[0];
    receta_personal[1] = leida.receta_personal[1];
    receta_personal[2] = leida.receta_personal[2];
    receta_personal[3] = leida.receta_personal[3];
}
bool eeprom_test(void) {
    uint8_t test_val = 0xA0;
    uint8_t read_val = 0;

    // Escribir un byte
    HAL_StatusTypeDef status_write = HAL_I2C_Mem_Write(
        &hi2c2,
        EEPROM_I2C_ADDR,
        0x0000,
        I2C_MEMADD_SIZE_16BIT,
        &test_val,
        1,
        50
    );

    if (status_write != HAL_OK) {
        return false;  // Error de escritura
    }

    HAL_Delay(5); // Tiempo de escritura

    // Leer el byte
    HAL_StatusTypeDef status_read = HAL_I2C_Mem_Read(
        &hi2c2,
        EEPROM_I2C_ADDR,
        0x0000,
        I2C_MEMADD_SIZE_16BIT,
        &read_val,
        1,
        50
    );

    if (status_read != HAL_OK) {
        return false;  // Error de lectura
    }

    return (read_val == test_val);  // Solo retorna true si se leyó bien
}

void eeprom_start_read(void) {
    if (eeprom_leyendo || eeprom_terminado) return;  // evitar reinicio

    eeprom_index = 0;
    eeprom_leyendo = 1;
    eeprom_terminado = 0;
}
void eeprom_update(void) {
    if (!eeprom_leyendo || eeprom_terminado) return;

    if (HAL_I2C_Mem_Read(EEPROM_I2C, EEPROM_I2C_ADDR,
                         EEPROM_CONFIG_ADDR + eeprom_index,
                         I2C_MEMADD_SIZE_16BIT,
                         &eeprom_buffer[eeprom_index], 1, EEPROM_TIMEOUT) == HAL_OK) {
        eeprom_index++;

        if (eeprom_index >= sizeof(ConfigEEPROM)) {
            eeprom_leyendo = 0;
            eeprom_terminado = 1;

            aplicar_config((ConfigEEPROM*)eeprom_buffer);  // ahora sí, actualizar
        }
    }
}

void aplicar_config(ConfigEEPROM* cfg) {
    temp_deseada     = cfg->temp_deseada;
    cafe_seleccionado = cfg->cafe_seleccionado;
    stock_cafe       = cfg->stock[0];
    stock_leche      = cfg->stock[1];
    stock_agua       = cfg->stock[2];
    stock_chocolate  = cfg->stock[3];

    for (int i = 0; i < 4; i++) {
        receta_personal[i] = cfg->receta_personal[i];
    }
}

void eeprom_save_update(void) {
    if (!eeprom_guardando || eeprom_terminado) return;

    if (HAL_I2C_Mem_Write(EEPROM_I2C, EEPROM_I2C_ADDR,
                          EEPROM_CONFIG_ADDR + eeprom_index,
                          I2C_MEMADD_SIZE_16BIT,
                          &eeprom_buffer[eeprom_index], 1, EEPROM_TIMEOUT) == HAL_OK) {
        eeprom_index++;

        if (eeprom_index >= sizeof(ConfigEEPROM)) {
            eeprom_guardando = 0;
            eeprom_terminado = 1;
        }
    }
}


