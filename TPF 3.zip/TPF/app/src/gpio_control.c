#include "gpio_control.h"

void led_on(uint8_t led_num) {
    switch (led_num) {
        case 1: HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET); break;
        case 2: HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET); break;
        case 3: HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_RESET); break;
        case 4: HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin, GPIO_PIN_RESET); break;
    }
}

void led_off(uint8_t led_num) {
    switch (led_num) {
        case 1: HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET); break;
        case 2: HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET); break;
        case 3: HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_SET); break;
        case 4: HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin, GPIO_PIN_SET); break;
    }
}

void led_toggle(uint8_t led_num) {
    switch (led_num) {
        case 1: HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin); break;
        case 2: HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin); break;
        case 3: HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin); break;
        case 4: HAL_GPIO_TogglePin(LED4_GPIO_Port, LED4_Pin); break;
    }
}

void led_wave_effect(void) {
    static uint32_t last_step = 0;
    static uint8_t phase = 0;

    if (HAL_GetTick() - last_step >= 100) {
        last_step = HAL_GetTick();

        switch (phase) {
            case 0: led_off(1); break;
            case 1: led_off(2); break;
            case 2: led_off(3); break;
            case 3: led_off(4); break;

            case 4: led_soft_off_start(1); break;
            case 5: led_soft_off_start(2); break;
            case 6: led_soft_off_start(3); break;
            case 7: led_soft_off_start(4); break;
        }

        phase = (phase + 1) % 8;
    }

    // Llamar siempre para avanzar el efecto
    led_soft_off_update();
}


typedef struct {
    uint8_t led;
    uint8_t duty_index;
    uint8_t active;
    uint32_t last_change;
} soft_led_t;

soft_led_t led_soft[4];  // uno por LED si querés que funcionen en paralelo

const uint8_t fade_pattern[10] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};

void led_soft_off_start(uint8_t led_num) {
    led_soft[led_num - 1].led = led_num;
    led_soft[led_num - 1].duty_index = 0;
    led_soft[led_num - 1].active = 1;
    led_soft[led_num - 1].last_change = HAL_GetTick();
}

void led_soft_off_update(void) {
    for (int i = 0; i < 4; i++) {
        if (!led_soft[i].active) continue;

        uint32_t now = HAL_GetTick();
        if (now - led_soft[i].last_change >= 1) {
            led_soft[i].last_change = now;

            // Alterna encendido/apagado según patrón
            led_off(led_soft[i].led);
            HAL_Delay(1);  // opcional: simular PWM (se puede quitar para evitar bloqueo)
            led_on(led_soft[i].led);

            led_soft[i].duty_index++;
            if (led_soft[i].duty_index >= sizeof(fade_pattern)) {
                led_on(led_soft[i].led);  // aseguro apagado
                led_soft[i].active = 0;
            }
        }
    }
}



// Created by Jorge - versión optimizada

void gpio_pin_on(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin) {
  HAL_GPIO_WritePin(GPIOx, GPIO_Pin, GPIO_PIN_SET);
}

void gpio_pin_off(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin) {
  HAL_GPIO_WritePin(GPIOx, GPIO_Pin, GPIO_PIN_RESET);
}

void gpio_pins_on(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pins) {
  GPIOx->BSRR = GPIO_Pins;  // set bits at once
}

void gpio_pins_off(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pins) {
  GPIOx->BRR = GPIO_Pins;   // reset bits at once
}
